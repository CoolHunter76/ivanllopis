# Vida laboral + Matrix
Patch completo sobre el snapshot facilitado. Configure PUBLIC_CONTACT_URL en staging/producción para dirigir el CTA a un canal público de contacto verificado.
